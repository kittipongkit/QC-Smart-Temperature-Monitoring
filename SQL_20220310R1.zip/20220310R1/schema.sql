USE [master]
GO
/****** Object:  Database [AJI_NK_TEMP_QC]    Script Date: 3/10/2022 2:55:23 PM ******/
CREATE DATABASE [AJI_NK_TEMP_QC]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'TempMonitorDB', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\AJI_NK_TEMP_QC.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'TempMonitorDB_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\AJI_NK_TEMP_QC_log.ldf' , SIZE = 73728KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [AJI_NK_TEMP_QC].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET ARITHABORT OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET  DISABLE_BROKER 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET  MULTI_USER 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET DB_CHAINING OFF 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET QUERY_STORE = OFF
GO
USE [AJI_NK_TEMP_QC]
GO
/****** Object:  User [omron]    Script Date: 3/10/2022 2:55:23 PM ******/
CREATE USER [omron] FOR LOGIN [omron] WITH DEFAULT_SCHEMA=[dbo]
GO
ALTER ROLE [db_owner] ADD MEMBER [omron]
GO
/****** Object:  Table [dbo].[ct_foor]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ct_foor](
	[foor_id] [int] IDENTITY(1,1) NOT NULL,
	[foor_name] [nvarchar](100) NULL,
	[foor_description] [nvarchar](100) NULL,
	[last_update_datetime] [datetime] NOT NULL,
	[status_flag] [varchar](1) NULL,
 CONSTRAINT [PK_ct_foor] PRIMARY KEY CLUSTERED 
(
	[foor_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ct_location]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ct_location](
	[location_id] [int] IDENTITY(1,1) NOT NULL,
	[location_name] [nvarchar](100) NULL,
	[location_description] [nvarchar](100) NULL,
	[last_update_datetime] [datetime] NOT NULL,
	[status_flag] [varchar](1) NULL,
 CONSTRAINT [PK_ct_zone] PRIMARY KEY CLUSTERED 
(
	[location_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ct_mail]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ct_mail](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[person_name] [nvarchar](100) NULL,
	[email_address] [nvarchar](100) NULL,
	[last_update_datetime] [datetime] NOT NULL,
	[status_flag] [varchar](1) NULL,
 CONSTRAINT [PK_ct_mail] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ct_setting]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ct_setting](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[temp_number] [int] NULL,
	[limit_hi] [decimal](5, 2) NULL,
	[limit_low] [decimal](5, 2) NULL,
	[warning_hi] [decimal](5, 2) NULL,
	[warning_low] [decimal](5, 2) NULL,
	[enable_limit_hi] [varchar](1) NULL,
	[enable_limit_low] [varchar](1) NULL,
	[enable_warning_hi] [varchar](1) NULL,
	[enable_warning_low] [varchar](1) NULL,
	[line_active] [varchar](1) NULL,
	[temp_active] [varchar](1) NULL,
	[last_update_datetime] [datetime] NULL,
	[status_flag] [varchar](1) NULL,
 CONSTRAINT [PK_ct_limit_value] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ct_temp]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ct_temp](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[temp_number] [int] NULL,
	[temp_name] [nvarchar](100) NULL,
	[tool_id] [int] NULL,
	[location_id] [int] NULL,
	[foor_id] [int] NULL,
	[last_update_datetime] [datetime] NULL,
	[status_flag] [varchar](1) NULL,
 CONSTRAINT [PK_ct_temp] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ct_tool]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ct_tool](
	[tool_id] [int] IDENTITY(1,1) NOT NULL,
	[tool_name] [nvarchar](100) NULL,
	[tool_description] [nvarchar](100) NULL,
	[last_update_datetime] [datetime] NOT NULL,
	[status_flag] [varchar](1) NULL,
 CONSTRAINT [PK_ct_tool] PRIMARY KEY CLUSTERED 
(
	[tool_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tr_event]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tr_event](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[tr_temp_id] [int] NULL,
	[event_type] [varchar](2) NULL,
	[create_datetime] [datetime] NULL,
	[temp_number] [int] NULL,
	[tool_id] [int] NULL,
	[tool_name] [nvarchar](100) NULL,
	[location_name] [nvarchar](100) NULL,
	[foor_name] [nvarchar](100) NULL,
	[temp_name] [nvarchar](100) NULL,
	[event_detail] [nvarchar](200) NULL,
	[notify_datetime] [datetime] NULL,
 CONSTRAINT [PK_tr_event] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tr_log]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tr_log](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[log_type] [varchar](10) NULL,
	[is_suscess] [varchar](1) NULL,
	[create_datetime] [datetime] NULL,
 CONSTRAINT [PK_tr_log] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tr_temp]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tr_temp](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[temp_number] [int] NULL,
	[temp_actual] [decimal](5, 2) NULL,
	[ct_temp_id] [int] NULL,
	[ct_setting_id] [int] NULL,
	[plc_datetime] [datetime] NULL,
	[create_datetime] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[tr_temp_1]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tr_temp_1](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[temp1] [real] NULL,
	[temp2] [real] NULL,
	[temp3] [real] NULL,
	[ct_setting_t1] [int] NULL,
	[ct_setting_t2] [int] NULL,
	[ct_setting_t3] [int] NULL,
	[plc_datetime] [datetime] NULL,
	[create_datetime] [datetime] NULL,
 CONSTRAINT [PK_tr_temp] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [NonClusteredIndex-20220202-140753]    Script Date: 3/10/2022 2:55:23 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20220202-140753] ON [dbo].[ct_setting]
(
	[status_flag] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [NonClusteredIndex-20220207-234001]    Script Date: 3/10/2022 2:55:23 PM ******/
CREATE NONCLUSTERED INDEX [NonClusteredIndex-20220207-234001] ON [dbo].[tr_event]
(
	[tr_temp_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[tr_log] ADD  CONSTRAINT [DF_tr_log_create_datetime]  DEFAULT (getdate()) FOR [create_datetime]
GO
/****** Object:  StoredProcedure [dbo].[pAutoInsert_tr_temp]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pAutoInsert_tr_temp]
AS
BEGIN
	DECLARE @i int = 1

	-- refig1 0-6 c
	WHILE @i <= 3
	begin
			insert into [dbo].[tr_temp]
           ([temp_number],[temp_actual])
			values
			(@i
           ,cast(RAND()*(6-1)+1 as decimal(5,2)))

		   SET @i = @i + 1
	end

	-- Incubator1 0-6 c
	WHILE @i <= 14
	begin
			insert into [dbo].[tr_temp]
           ([temp_number],[temp_actual])
			values
			(@i
           ,cast(RAND()*(36-25)+25 as decimal(5,2)))

		   SET @i = @i + 1
	end

	-- Oven1/1 60-80 c
	WHILE @i <= 16
	begin
			insert into [dbo].[tr_temp]
           ([temp_number],[temp_actual])
			values
			(@i
           ,cast(RAND()*(85-60)+60 as decimal(5,2)))

		   SET @i = @i + 1
	end

	-- Oven1/2 180-190 c
	WHILE @i <= 25
	begin
			insert into [dbo].[tr_temp]
           ([temp_number],[temp_actual])
			values
			(@i
           ,cast(RAND()*(195-170)+170 as decimal(5,2)))

		   SET @i = @i + 1
	end

	-- Incubator2 20 c
	WHILE @i <= 27
	begin
			insert into [dbo].[tr_temp]
           ([temp_number],[temp_actual])
			values
			(@i
           ,cast(RAND()*(25-18)+18 as decimal(5,2)))

		   SET @i = @i + 1
	end

	-- refig 0-15 c
	WHILE @i <= 35
	begin
			insert into [dbo].[tr_temp]
           ([temp_number],[temp_actual])
			values
			(@i
           ,cast(RAND()*(15-0)+0 as decimal(5,2)))

		   SET @i = @i + 1
	end




END
GO
/****** Object:  StoredProcedure [dbo].[pGet_data_for_report]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:  <Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get temp data for 1 day>
-- Use at : <report page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_data_for_report] (@selected_date datetime, @sampling_min int = 15)
AS
BEGIN

 declare @tablex table (avg_t1 decimal(4,2),avg_t2 decimal(4,2),avg_t3 decimal(4,2)
  ,t1_low decimal(5,2),t1_hi decimal(5,2),t2_low decimal(5,2),t2_hi decimal(5,2)
  ,t3_low decimal(5,2),t3_hi decimal(5,2),t_min datetime)
 insert into @tablex
 select avg(t1.temp1) as avg_t1
  ,avg(t1.temp2) as avg_t2
  ,avg(t1.temp3) as avg_t3
  ,(select top 1 st.limit_low from ct_setting st where st.ID = max(t1.ct_setting_t1)) as temp1_low
  ,(select top 1 st.limit_hi from ct_setting st where st.ID = max(t1.ct_setting_t1)) as temp1_hi
  ,(select top 1 st.limit_low from ct_setting st where st.ID = max(t1.ct_setting_t2))  as temp2_low
  ,(select top 1 st.limit_hi from ct_setting st where st.ID = max(t1.ct_setting_t2))  as temp2_low
  ,(select top 1 st.limit_low from ct_setting st where st.ID = max(t1.ct_setting_t3)) as temp3_low
  ,(select top 1 st.limit_hi from ct_setting st where st.ID = max(t1.ct_setting_t3)) as temp3_hi
  ,dateadd(minute,(datediff(minute,0,t1.create_datetime)/@sampling_min)*@sampling_min,0) t_min 
 from tr_temp t1 
 where cast(t1.create_datetime as date) = cast(@selected_date as date)
 group by dateadd(minute,(datediff(minute,0,t1.create_datetime)/@sampling_min)*@sampling_min,0) 

 -- Cal result
 select 
      main.t_min  as datetime
  ,main.avg_t1 as avg_temp1
  ,main.t1_low as temp1_lo
  ,main.t1_hi as temp1_hi
  ,( case
    when main.avg_t1 between main.t1_low and main.t1_hi then 'OK'
    else 'NG' end) as temp1_result
  ,main.avg_t2 as avg_temp2
  ,main.t2_low as temp2_lo
  ,main.t2_hi as temp2_hi
  ,( case
    when main.avg_t2 between main.t2_low and main.t2_hi then 'OK'
    else 'NG' end) as temp2_result
  ,main.avg_t3 as avg_temp3
  ,main.t3_low as temp3_lo
  ,main.t3_hi as temp3_hi
  ,( case
    when main.avg_t3 between main.t3_low and main.t3_hi then 'OK'
    else 'NG' end) as temp3_result
 from @tablex main


END
GO
/****** Object:  StoredProcedure [dbo].[pGet_data_report]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:  <Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get temp data by start to end datetime>
-- Use at : <data page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_data_report]
AS
BEGIN
 
	 -- Create temp
	 declare @tablex table (HourTime datetime, avg_t1 decimal(4,2),avg_t2 decimal(4,2),avg_t3 decimal(4,2)
	 , min_t1 decimal(4,2),min_t2 decimal(4,2),min_t3 decimal(4,2), max_t1 decimal(4,2),max_t2 decimal(4,2),max_t3 decimal(4,2))
	insert into @tablex
	select cast(cast(cast(cast(sd.create_datetime as float)*24 as bigint) as float)/24 as datetime) as HourTime
		, avg(sd.temp1) 
		, avg(sd.temp2) 
		, avg(sd.temp3)
		, min(sd.temp1)
		, min(sd.temp2)
		, min(sd.temp3)
		, max(sd.temp1)
		, max(sd.temp2)
		, max(sd.temp3)
	from  tr_temp sd
	where cast(sd.create_datetime as date) = cast(getdate()-1 as date)
	group by cast(cast(cast(cast(sd.create_datetime as float)*24 as bigint) as float)/24 as datetime)


	--select * from @tablex

	-- result 1
	select DATEADD(hour,-1 , x.HourTime) 'เวลาเริ่มต้น'
	, x.HourTime  'เวลาสิ้นสุด'
	, x.avg_t1 'ห้องฟีด AVG'
	, x.min_t1 'ห้องฟีด MIN'
	, x.max_t1 'ห้องฟีด MAX'
	, x.avg_t2 'ห้องเตรียม AVG'
	, x.min_t2 'ห้องเตรียม MIN'
	, x.max_t2 'ห้องเตรียม MAX'
	, x.avg_t3 'ห้องเย็น AVG'
	, x.min_t3 'ห้องเย็น MIN'
	, x.max_t3 'ห้องเย็น MAX'
	from @tablex x
	where cast( DATEADD(hour,-1 , x.HourTime)  as date) =  cast(getdate()-1 as date)



END
GO
/****** Object:  StoredProcedure [dbo].[pGet_data_report_app]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:  <Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get temp data by start to end datetime>
-- Use at : <data page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_data_report_app] (@selected_date datetime)
AS
BEGIN
 
  -- Create temp
  declare @tablex table (HourTime datetime, avg_t1 decimal(4,2),avg_t2 decimal(4,2),avg_t3 decimal(4,2)
  , min_t1 decimal(4,2),min_t2 decimal(4,2),min_t3 decimal(4,2), max_t1 decimal(4,2),max_t2 decimal(4,2),max_t3 decimal(4,2))
 insert into @tablex
 select cast(cast(cast(cast(sd.create_datetime as float)*24 as bigint) as float)/24 as datetime) as HourTime
  , avg(sd.temp1) 
  , avg(sd.temp2) 
  , avg(sd.temp3)
  , min(sd.temp1)
  , min(sd.temp2)
  , min(sd.temp3)
  , max(sd.temp1)
  , max(sd.temp2)
  , max(sd.temp3)
 from  tr_temp sd
 where cast(sd.create_datetime as date) = cast(@selected_date as date)
 group by cast(cast(cast(cast(sd.create_datetime as float)*24 as bigint) as float)/24 as datetime)


 --select * from @tablex

 -- result 1
 select DATEADD(hour,-1 , x.HourTime) 'เวลาเริ่มต้น'
 , x.HourTime  'เวลาสิ้นสุด'
 , x.min_t3 'ห้องเย็น MIN'
 , x.max_t3 'ห้องเย็น MAX' 
 , x.avg_t3 'ห้องเย็น AVG'
 , x.min_t2 'ห้องเตรียม MIN'
 , x.max_t2 'ห้องเตรียม MAX'
 , x.avg_t2 'ห้องเตรียม AVG'  
 , x.min_t1 'ห้องฟีด MIN'
 , x.max_t1 'ห้องฟีด MAX'
 , x.avg_t1 'ห้องฟีด AVG'
 ,(select top 1 st.limit_low from ct_setting st where st.last_update_datetime < DATEADD(hour,-1 , x.HourTime) and st.zone_id = 3 order by st.ID desc) as temp1_low
 ,(select top 1 st.limit_hi  from ct_setting st where st.last_update_datetime < DATEADD(hour,-1 , x.HourTime) and st.zone_id = 3 order by st.ID desc) as temp1_hi
 ,(select top 1 st.limit_low from ct_setting st where st.last_update_datetime < DATEADD(hour,-1 , x.HourTime) and st.zone_id = 2 order by st.ID desc) as temp2_low
 ,(select top 1 st.limit_hi  from ct_setting st where st.last_update_datetime < DATEADD(hour,-1 , x.HourTime) and st.zone_id = 2 order by st.ID desc) as temp2_hi
 ,(select top 1 st.limit_low from ct_setting st where st.last_update_datetime < DATEADD(hour,-1 , x.HourTime) and st.zone_id = 1 order by st.ID desc) as temp3_low
 ,(select top 1 st.limit_hi  from ct_setting st where st.last_update_datetime < DATEADD(hour,-1 , x.HourTime) and st.zone_id = 1 order by st.ID desc) as temp3_hi
 from @tablex x
 where cast( DATEADD(hour,-1 , x.HourTime)  as date) =  cast(@selected_date as date)



END
GO
/****** Object:  StoredProcedure [dbo].[pGet_data_with_sampling_time]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:  <Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get temp data by start to end datetime>
-- Use at : <data page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_data_with_sampling_time] (@temp_number int = 1  , @start_date datetime, @end_date datetime, @sampling_no int = 1)
AS
BEGIN
	 -- check datetime
	 if (@start_date is null) begin set @start_date = getdate() end
	 if (@end_date is null) begin set @end_date = getdate() end

	 -- set sampling minute
	 declare @sampling_min int = 5
	 select @sampling_min = (case
	   when @sampling_no = 1 THEN 5
	   when @sampling_no = 2 THEN 15
	   when @sampling_no = 3 THEN 30
	   when @sampling_no = 4 THEN 60
	  else  5
	  end)
	  
	 -- select temp_actual by temp_number
	 declare @tabletemp table (temp_number int
		, temp_actual decimal(5,2)
		, ct_setting_id int
		, create_datetime datetime)
	 insert into @tabletemp
	 select temp.temp_number 
		, temp.temp_actual
		, temp.ct_setting_id
		, temp.create_datetime
	 from tr_temp temp
	 where temp.temp_number = @temp_number

	 -- select temp_avg by time group
	 declare @tablex table (avg_t1 decimal(5,2)
		,t1_alow decimal(5,2)
		,t1_ahi decimal(5,2)
		,t1_wlow decimal(5,2)
		,t1_whi decimal(5,2)
		,t_min datetime)
	 insert into @tablex
	 select avg(t1.temp_actual) as avg_t1
		,(select top 1 st.limit_low from ct_setting st where st.ID = max(t1.ct_setting_id)) as temp1_alow
		,(select top 1 st.limit_hi from ct_setting st where st.ID = max(t1.ct_setting_id)) as temp1_ahi
		,(select top 1 st.warning_low from ct_setting st where st.ID = max(t1.ct_setting_id)) as temp1_wlow
		,(select top 1 st.warning_hi from ct_setting st where st.ID = max(t1.ct_setting_id)) as temp1_whi
		,dateadd(minute,(datediff(minute,0,t1.create_datetime)/@sampling_min)*@sampling_min,0) as t_min 
	 from @tabletemp t1 
	 where cast(t1.create_datetime as date) between cast(@start_date as date) and  cast(@end_date as date)
	 group by dateadd(minute,(datediff(minute,0,t1.create_datetime)/@sampling_min)*@sampling_min,0) 

	 -- Call last result
	  select 
		main.t_min  as datetime
	   ,main.avg_t1 as avg_temp
	   ,main.t1_alow as temp_alo
	   ,main.t1_ahi as temp_ahi
	   ,main.t1_wlow as temp_wlo
	   ,main.t1_whi as temp_whi
	   ,( case
		 when main.avg_t1 between main.t1_alow and main.t1_ahi then 'OK'
		 else 'NG' end) as temp_result
	  from @tablex main

END
GO
/****** Object:  StoredProcedure [dbo].[pGet_event]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get event data by tool_id>
-- Use at : <event page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_event](@tool_id int)
AS
BEGIN
	SET NOCOUNT ON;

	if(@tool_id between 1 and 3)
		SELECT top 50 x.create_datetime as 'Date Time'
			, x.temp_number as 'Temp Number'
			, x.temp_name	as 'Temp Name'
			, x.tool_name as 'Tool'
			, x.location_name as 'Location'
			, x.foor_name as 'Foor'
			, x.event_type as 'Status'
			, x.event_detail as 'Detail'
		from tr_event x where x.tool_id = @tool_id 
		order by id desc
	else
		SELECT top 50 x.create_datetime as 'Date Time'
			, x.temp_number as 'Temp Number'
			, x.temp_name	as 'Temp Name'
			, x.tool_name as 'Tool'
			, x.location_name as 'Location'
			, x.foor_name as 'Foor'
			, x.event_type as 'Status'
			, x.event_detail as 'Detail'
		from tr_event x 
		order by id desc

END
GO
/****** Object:  StoredProcedure [dbo].[pGet_event_all]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get all 6 last event>
-- Use at : <overview page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_event_all]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT top 6 x.id
			, x.create_datetime
			, x.temp_name
			, x.tool_name
			, x.event_type 
	from tr_event x  
	order by id desc
END
GO
/****** Object:  StoredProcedure [dbo].[pGet_foor_name]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get all foor name for drop-down selection>
-- Use at : <data page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_foor_name]
AS
BEGIN

	SELECT main.foor_id
		, main.foor_name
	FROM ct_foor main
	WHERE main.status_flag = 'A'
	ORDER BY main.foor_id
	
END
GO
/****** Object:  StoredProcedure [dbo].[pGet_location_name]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get all location name for drop-down selection>
-- Use at : <data page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_location_name]
AS
BEGIN

	SELECT main.location_id
			, main.location_name
	FROM ct_location main
	WHERE main.status_flag = 'A'
	ORDER BY main.location_id 
	
END
GO
/****** Object:  StoredProcedure [dbo].[pGet_setting]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get setting by tool_id>
-- Use at : <setting page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_setting](@tool_id int)
AS
BEGIN
	
	--	Main quiery
	declare @tablex table(ID int
		,temp_number int
		,tool_id int
		,tool_name nvarchar(100)
		,location_name nvarchar(100)
		,foor_name nvarchar(100)
		,temp_name nvarchar(100)
		,limit_hi decimal(5,2)
		,limit_low decimal(5,2)
		,warning_hi decimal(5,2)
		,warning_low decimal(5,2)		
		,enable_ahi varchar(1)
		,enable_alow varchar(1)		
		,enable_whi varchar(1)
		,enable_wlow varchar(1)
		,line_active varchar(1)
		,temp_active varchar(1)
		,last_update_datetime datetime
		,status_flag varchar(1))			
	insert @tablex
	select x.ID as ID
		,x.temp_number as temp_number
		,(select top 1 st.tool_id from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A') as tool_id	
		,(select top 1 st.tool_name from ct_tool st where st.tool_id = (select top 1 st.tool_id from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A') and st.status_flag = 'A') as tool_name
		,(select top 1 st.location_name from ct_location st where st.location_id = (select top 1 st.location_id from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A') and st.status_flag = 'A') as location_name
		,(select top 1 st.foor_name from ct_foor st where st.foor_id = (select top 1 st.foor_id from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A') and st.status_flag = 'A') as foor
		,(select top 1 st.temp_name from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A') as temp_name		
		,x.limit_hi as temp_ahi
		,x.limit_low as temp_alow
		,x.warning_hi as temp_whi
		,x.warning_low as temp_wlow
		,x.enable_limit_hi as enable_ahi
		,x.enable_limit_low as enable_alow
		,x.enable_warning_hi as enable_whi
		,x.enable_warning_low as enable_wlow
		,x.line_active as line_active
		,x.temp_active as temp_active
		,x.last_update_datetime as update_datetime
		,x.status_flag as status_flag
	 from ct_setting x 
	 where x.status_flag = 'A'
	 order by x.temp_number desc

	 -- Cal result
	select 
	     main.ID as ID
		,main.temp_number as temp_number
		,main.tool_id	 as tool_id	
		,main.tool_name as tool_name
		,main.location_name as location_name
		,main.foor_name as foor_name
		,main.temp_name as temp_name
		,main.limit_hi as temp_ahi
		,main.limit_low as temp_alow
		,main.warning_hi as temp_whi
		,main.warning_low as temp_wlow
		,main.enable_alow as enable_alow
		,main.enable_ahi as enable_ahi
		,main.enable_wlow as enable_wlow
		,main.enable_whi as enable_whi		
		,main.line_active as line_active
		,main.temp_active as temp_active
		,main.last_update_datetime as update_datetime
	from @tablex main
	where main.tool_id = @tool_id and main.status_flag = 'A'
	order by main.temp_number

END
GO
/****** Object:  StoredProcedure [dbo].[pGet_setting_actual]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:  <Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get actual setting>
-- Use at : <overview page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_setting_actual]
AS
BEGIN

	SELECT main.ID
	, main.temp_number
	, (select top 1 x.temp_name from ct_temp x where x.temp_number = main.temp_number and x.status_flag = 'A') as temp_name
	, (select top 1 x.foor_name from ct_foor x where x.foor_id = (select top 1 st.foor_id from ct_temp st where st.temp_number = main.temp_number and st.status_flag = 'A') and x.status_flag = 'A') as foor_name
	, main.limit_hi
	, main.limit_low
	, main.warning_hi
	, main.warning_low
	, main.enable_limit_hi
	, main.enable_limit_low
	, main.enable_warning_hi
	, main.enable_warning_low
	, main.line_active
	, main.temp_active
	FROM ct_setting main
	WHERE main.status_flag = 'A'
	ORDER BY main.temp_number 

END
GO
/****** Object:  StoredProcedure [dbo].[pGet_setting_by_no]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get setting by temp_nomber>
-- Use at : <setting page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_setting_by_no](@temp_number int)
AS
BEGIN

	--	Main quiery
	declare @tablex table(ID int
		,temp_number int
		,temp_name nvarchar(100)
		,tool_id int
		,tool_name nvarchar(100)
		,location_id int
		,location_name nvarchar(100)
		,foor_id int
		,foor_name nvarchar(100)		
		,limit_hi decimal(5,2)
		,limit_low decimal(5,2)
		,warning_hi decimal(5,2)
		,warning_low decimal(5,2)		
		,enable_ahi varchar(1)
		,enable_alow varchar(1)		
		,enable_whi varchar(1)
		,enable_wlow varchar(1)
		,line_active varchar(1)
		,temp_active varchar(1)
		,last_update_datetime datetime
		,status_flag varchar(1))			
	insert @tablex
	select x.ID as ID
		,x.temp_number as temp_number
		,(select top 1 st.temp_name from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A') as temp_name
		,(select top 1 st.tool_id from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A') as tool_id
		,(select top 1 st.tool_name from ct_tool st where st.tool_id = (select top 1 st.tool_id from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A') and st.status_flag = 'A') as tool_name
		,(select top 1 st.location_id from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A')  as location_id
		,(select top 1 st.location_name from ct_location st where st.location_id = (select top 1 st.location_id from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A') and st.status_flag = 'A') as location_name
		,(select top 1 st.foor_id from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A') as foor_id
		,(select top 1 st.foor_name from ct_foor st where st.foor_id = (select top 1 st.foor_id from ct_temp st where st.temp_number = x.temp_number and st.status_flag = 'A') and st.status_flag = 'A') as foor_name			
		,x.limit_hi as temp_ahi
		,x.limit_low as temp_alow
		,x.warning_hi as temp_whi
		,x.warning_low as temp_wlow
		,x.enable_limit_hi as enable_ahi
		,x.enable_limit_low as enable_alow
		,x.enable_warning_hi as enable_whi
		,x.enable_warning_low as enable_wlow
		,x.line_active as line_active
		,x.temp_active as temp_active
		,x.last_update_datetime as update_datetime
		,x.status_flag as status_flag
	 from ct_setting x 
	 where x.status_flag = 'A'
	 order by x.temp_number desc

	 -- Cal result
	select 
	     main.ID as ID
		,main.temp_number as temp_number
		,main.temp_name as temp_name
		,main.tool_id as tool_id
		,main.tool_name	 as tool_name
		,main.location_id as location_id
		,main.location_name as location_name
		,main.foor_id as foor_id	
		,main.foor_name as foor_name		
		,main.limit_hi as temp_ahi
		,main.limit_low as temp_alow
		,main.warning_hi as temp_whi
		,main.warning_low as temp_wlow
		,main.enable_alow as enable_alow
		,main.enable_ahi as enable_ahi
		,main.enable_wlow as enable_wlow
		,main.enable_whi as enable_whi		
		,main.line_active as line_active
		,main.temp_active as temp_active
		,main.last_update_datetime as update_datetime
	from @tablex main
	where main.temp_number = @temp_number and main.status_flag = 'A'

END
GO
/****** Object:  StoredProcedure [dbo].[pGet_status]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get avg temp, warning, out of rang of tool for today>
-- Use at : <overview>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_status]
AS
BEGIN
	declare @tool1_alarm int, @tool1_warning int
	declare @tool2_alarm int, @tool2_warning int
	declare @tool3_alarm int, @tool3_warning int


	-- select tr_event today
	declare @tableEvent table (tool_id int
		, event_type varchar(2)
		, create_datetime datetime)
	insert into @tableEvent
	select s1.tool_id
		, s1.event_type
		, s1.create_datetime
	from tr_event s1
	where s1.create_datetime > DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE()))

	-- select temp_actual today
	declare @tableTemp table ( temp_actual decimal(5,2)
		,tool_id int
		,create_datetime datetime)
	insert into @tableTemp
	select s1.temp_actual
		,(select x.tool_id from ct_temp x where x.id = s1.ct_temp_id)
		,s1.create_datetime
	from tr_temp s1
	where s1.create_datetime > DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE()))

	
	 -- call result
	 select top 1 CONVERT(DECIMAL(5,2),(select avg(temp_actual) from @tableTemp t1 where t1.tool_id = 1)) as tool1avg
		,CONVERT(DECIMAL(5,2),(select avg(temp_actual) from @tableTemp t1 where t1.tool_id = 2)) as tool2avg
		,CONVERT(DECIMAL(5,2),(select avg(temp_actual) from @tableTemp t1 where t1.tool_id = 3)) as tool3avg
		,(select count(x.event_type) from @tableEvent x where (x.event_type = 'HH' or x.event_type = 'LL') and x.tool_id = 1) as tool1_alarm
		,(select count(x.event_type) from @tableEvent x where (x.event_type = 'H' or x.event_type = 'L') and x.tool_id = 1) as tool1_warning
		,(select count(x.event_type) from @tableEvent x where (x.event_type = 'HH' or x.event_type = 'LL') and x.tool_id = 2) as tool2_alarm
		,(select count(x.event_type) from @tableEvent x where (x.event_type = 'H' or x.event_type = 'L') and x.tool_id = 2) as tool2_warning
		,(select count(x.event_type) from @tableEvent x where (x.event_type = 'HH' or x.event_type = 'LL') and x.tool_id = 3) as tool3_alarm
		,(select count(x.event_type) from @tableEvent x where (x.event_type = 'H' or x.event_type = 'L') and x.tool_id = 3) as tool3_warning
	 from tr_temp main

END
GO
/****** Object:  StoredProcedure [dbo].[pGet_status_tool]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get status of tool every hour>
-- Use at : <overview>
-- =============================================
-- sample
-- time	t1	t2	t3
--	00	1	1	0
--	01	0	0	2
--	02	2	0	0
--		...
--	24	1	0	1

CREATE PROCEDURE [dbo].[pGet_status_tool]
AS
BEGIN
		declare @tableEvent table (create_datetime datetime
		, tool_id int
		, event_status int)
	insert into @tableEvent
	select s1.create_datetime
		, s1.tool_id
		, (case 
			when s1.event_type = 'N' then  0
			when s1.event_type = 'H' or s1.event_type = 'L' then 1
			when s1.event_type = 'HL' or s1.event_type = 'LL' then 2
			else 3
			end)
	from tr_event s1
	where s1.create_datetime > DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE()))


	select cast(cast(cast(cast(sd.create_datetime as float)*24 as bigint) as float)/24 as datetime) as HourTime
		,max(sd.event_status) as tool_status1
		,max(sd.event_status) as tool_status2
		,max(sd.event_status) as tool_status3
	from @tableEvent sd
	group by cast(cast(cast(cast(sd.create_datetime as float)*24 as bigint) as float)/24 as datetime)
END
GO
/****** Object:  StoredProcedure [dbo].[pGet_Temp_actual]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:  <Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get actual temp data for 1 sampling time>
-- Use at : <overview page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_Temp_actual] (@temp_number int)
AS
BEGIN

	--	Main quiery
	declare @tablex table(ID int, create_datetime datetime
		,temp_number int
		,temp_actual decimal(5,2)
		,ct_setting_id int
		,temp_alow decimal(5,2)
		,temp_ahi decimal(5,2)
		,temp_wlow decimal(5,2)
		,temp_whi decimal(5,2)
		,enable_alow varchar(1)
		,enable_ahi varchar(1)
		,enable_wlow varchar(1)
		,enable_whi varchar(1)
		,enable_line varchar(1)
		,enable_temp varchar(1))	
	insert @tablex
	select top 1 x.ID as ID
		,x.create_datetime  as create_datetime
		,x.temp_number as temp_number
		,x.temp_actual as temp_actual
		,x.ct_setting_id as ct_setting_id
		,(select top 1 st.limit_low from ct_setting st where st.ID = x.ct_setting_id) as temp_alow
		,(select top 1 st.limit_hi from ct_setting st where st.ID = x.ct_setting_id) as temp_ahi
		,(select top 1 st.warning_low from ct_setting st where st.ID = x.ct_setting_id) as temp_wlow
		,(select top 1 st.warning_hi from ct_setting st where st.ID = x.ct_setting_id) as temp_whi
		,(select top 1 st.enable_limit_low from ct_setting st where st.ID = x.ct_setting_id) as enable_alow
		,(select top 1 st.enable_limit_hi from ct_setting st where st.ID = x.ct_setting_id) as enable_ahi
		,(select top 1 st.enable_warning_low from ct_setting st where st.ID = x.ct_setting_id) as enable_wlow
		,(select top 1 st.enable_warning_hi from ct_setting st where st.ID = x.ct_setting_id) as enable_whi
		,(select top 1 st.line_active from ct_setting st where st.ID = x.ct_setting_id) as enable_line
		,(select top 1 st.temp_active from ct_setting st where st.ID = x.ct_setting_id) as enable_temp
	 from tr_temp x 
	 where x.temp_number = @temp_number
	 order by x.id desc

	--select * from @tablex

	-- Cal result
	select 
	     main.ID as ID
		,main.create_datetime  as create_datetime
		,main.temp_number as temp_number
		,main.temp_actual as temp_actual
		,main.ct_setting_id as ct_setting_id
		,main.temp_alow as temp_alow
		,main.temp_ahi as temp_ahi
		,main.temp_wlow as temp_wlow
		,main.temp_whi as temp_whi
		,main.enable_alow as enable_alow
		,main.enable_ahi as enable_ahi
		,main.enable_wlow as enable_wlow
		,main.enable_whi as enable_whi
		,main.enable_line as enable_line
		,main.enable_temp as enable_temp
		,( case
			 when (main.temp_actual >= main.temp_wlow) and (main.temp_actual <= main.temp_whi) then 'OK'
			 when (main.enable_whi = 'Y') and (main.temp_actual > main.temp_whi) and (main.temp_actual <= main.temp_ahi) then 'WH'
			 when (main.enable_ahi = 'Y') and (main.temp_actual > main.temp_ahi) then 'AH'
			 when (main.enable_wlow = 'Y') and (main.temp_actual < main.temp_wlow) and (main.temp_actual >= main.temp_alow) then 'WL'
			 when (main.enable_alow = 'Y') and (main.temp_actual < main.temp_alow) then 'AL'
			 else 'NG' end) as temp_result
	from @tablex main


END
GO
/****** Object:  StoredProcedure [dbo].[pGet_temp_name]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get all temp name for select data>
-- Use at : <data page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_temp_name](@tool_id int, @location_id int, @foor_id int)
AS
BEGIN
	if (@tool_id is null) begin set @tool_id = 1 end
	if (@location_id is null) begin set @location_id = 1 end
	if (@foor_id is null) begin set @foor_id = 1 end

	SELECT main.temp_number as temp_number
		, main.temp_name as temp_name
	FROM ct_temp main
	WHERE main.tool_id = @tool_id and main.location_id = @location_id and main.foor_id = @foor_id and main.status_flag = 'A'
	ORDER BY main.temp_number
	
END
GO
/****** Object:  StoredProcedure [dbo].[pGet_tool_name]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get all tool name for select data>
-- Use at : <data page>
-- =============================================
CREATE PROCEDURE [dbo].[pGet_tool_name]
AS
BEGIN

	SELECT main.tool_id
			, main.tool_name
	FROM ct_tool main
	WHERE main.status_flag = 'A'
	ORDER BY main.tool_id 
	
END
GO
/****** Object:  StoredProcedure [dbo].[pGetTempDataByToolId]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:  <Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get all temp data for start frist time>
-- Use at : <overview page>
-- =============================================
CREATE PROCEDURE [dbo].[pGetTempDataByToolId](@tool_id int = 1  , @start_date datetime, @end_date datetime, @sampling_no int = 1)
AS
BEGIN

	-- check datetime
	 if (@start_date is null) begin set @start_date = getdate() end
	 if (@end_date is null) begin set @end_date = getdate() end

	 -- set sampling minute
	 declare @sampling_min int = 5
	 select @sampling_min = (case
	   when @sampling_no = 1 THEN 5
	   when @sampling_no = 2 THEN 15
	   when @sampling_no = 3 THEN 30
	   when @sampling_no = 4 THEN 60
	  else  5
	  end)

	 -- select temp_actual by temp_number
	 declare @tabletemp table (temp_number int	 
		, temp_name nvarchar(100)
		, tool_id int
		, temp_actual decimal(5,2)
		, create_datetime datetime
		,t_min datetime)
	 insert into @tabletemp
	 select temp.temp_number 
		, (select x.temp_name from ct_temp x where x.temp_number = temp.temp_number and x.status_flag = 'A')
		, (select x.tool_id from ct_temp x where x.temp_number = temp.temp_number and x.status_flag = 'A')
		, temp.temp_actual		
		, temp.create_datetime
		,dateadd(minute,(datediff(minute,0,temp.create_datetime)/@sampling_min)*@sampling_min,0) as t_min 
	 from tr_temp temp
	 where (select x.tool_id from ct_temp x where x.temp_number = temp.temp_number and x.status_flag = 'A') = @tool_id
		and cast(temp.create_datetime as date) between cast(@start_date as date) and  cast(@end_date as date)

	 

	 -- select temp_avg by time group
	 declare @tablex table (create_datetime  datetime
		,t1 decimal(5,2)
		,t2 decimal(5,2)
		)
	 insert into @tablex
	 select main.create_datetime as create_datetime
		, (select x.temp_actual from @tabletemp x where x.temp_number = 1 and x.create_datetime = main.create_datetime)
		, (select x.temp_actual from @tabletemp x where x.temp_number = 2 and x.create_datetime = main.create_datetime)
	 from @tabletemp main 
	 --where cast(t1.create_datetime as date) between cast(@start_date as date) and  cast(@end_date as date)
	 --group by dateadd(minute,(datediff(minute,0,t1.create_datetime)/@sampling_min)*@sampling_min,0) 

	 ---- Call last result
	 -- select 
		--main.t_min  as datetime
	 --  ,main.avg_t1 as avg_temp
	 --  ,main.t1_alow as temp_alo
	 --  ,main.t1_ahi as temp_ahi
	 --  ,main.t1_wlow as temp_wlo
	 --  ,main.t1_whi as temp_whi
	 --  ,( case
		-- when main.avg_t1 between main.t1_alow and main.t1_ahi then 'OK'
		-- else 'NG' end) as temp_result
	 -- from @tablex main
	 select * from @tablex
END
GO
/****** Object:  StoredProcedure [dbo].[pProcessGetMailNotify]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pProcessGetMailNotify]
AS
BEGIN
	select x.email_address
	from ct_mail x
	where x.status_flag = 'A'
END
GO
/****** Object:  StoredProcedure [dbo].[pProcessSearchNotifyAlarm]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
CREATE PROCEDURE [dbo].[pProcessSearchNotifyAlarm]
AS
BEGIN
	--	token test	:	hj1TGTJOwYq8L78D2fYbhPKQhOAsgaG1KfJ1QRLa3Tb
	--	token prd	:	kIAHDQDNW0M61LF19rrMRm4GFdJlCA4dxKkYodTT8oJ
	declare @newline varchar(5) = '$$'
	select top 100 x.ID as tr_event_id
		, 'EX-1 Smart Notify' + @newline 
			+ '---------------------------' + @newline 
			+ 'Area : ' 
			+ (select top 1 isnull(ctz.zone_description, 'na') from ct_zone ctz where ctz.ID = x.zone_id and ctz.status_flag = 'A')  + @newline 
			+ 'Datetime : ' + convert(varchar, x.create_datetime, 120) +  @newline	
			+ 'Status : '
			--+ 'Event type : '
			+ ( case
					when x.event_type = 'L' then 'Lower (ต่ำกว่า)'
					when x.event_type = 'H' then 'Upper (สูงกว่า)'
					else 'Normal (กลับสู่ปกติ)'	
				 end ) + @newline 
			+ 'Message : ' +  x.event_detail	as 'message'
		,	'kIAHDQDNW0M61LF19rrMRm4GFdJlCA4dxKkYodTT8oJ'	line_token
	from tr_event x
	where x.notify_datetime is null
	order by x.ID

END
GO
/****** Object:  StoredProcedure [dbo].[pUpdate_setting]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description: <Get setting by zone_id>
-- Use at : <setting page>
-- =============================================
CREATE PROCEDURE [dbo].[pUpdate_setting](@temp_number int
	,@temp_name nvarchar(100)
	,@limit_hi decimal(5,2)
	,@limit_low decimal(5,2)
	,@warning_hi decimal(5,2)
	,@warning_low decimal(5,2)
	,@enable_limit_hi varchar(1)
	,@enable_limit_low varchar(1)
	,@enable_warning_hi varchar(1)
	,@enable_warning_low varchar(1)
	,@line_active varchar(1)
	,@temp_active varchar(1))
AS
BEGIN
	-- Update status_flag A -> U
	UPDATE [dbo].[ct_setting]
	SET [status_flag] = 'U'
	WHERE temp_number = @temp_number AND status_flag = 'A'

	-- Insert new ct_setting
	INSERT INTO [dbo].[ct_setting] 
	(temp_number
	 ,limit_hi
     ,limit_low
	 ,warning_hi
     ,warning_low
	 ,enable_limit_hi
     ,enable_limit_low
	 ,enable_warning_hi
     ,enable_warning_low
	 ,line_active
     ,temp_active
     ,last_update_datetime
     ,status_flag)
	 VALUES
	(@temp_number
	,@limit_hi
	,@limit_low
	,@warning_hi
	,@warning_low
	,@enable_limit_hi
	,@enable_limit_low
	,@enable_warning_hi
	,@enable_warning_low
	,@line_active
	,@temp_active
    ,getdate()
    ,'A')

	if(@temp_name != (select top 1 st.temp_name from ct_temp st where st.temp_number = @temp_number and st.status_flag = 'A'))
	begin
			-- Update status_flag A -> U
		UPDATE [dbo].[ct_temp]
		SET [status_flag] = 'U'
		WHERE temp_number = @temp_number AND status_flag = 'A'

		-- Insert new ct_temp
		INSERT INTO [dbo].ct_temp 
		(temp_number
		 ,temp_name
		 ,tool_id
		 ,location_id
		 ,foor_id
		 ,last_update_datetime
		 ,status_flag)
		 VALUES
		(@temp_number
		,@temp_name
		,(select top 1 st.tool_id from ct_temp st where st.temp_number = @temp_number order by st.id desc)
		,(select top 1 st.location_id from ct_temp st where st.temp_number = @temp_number order by st.id desc)
		,(select top 1 st.foor_id from ct_temp st where st.temp_number = @temp_number order by st.id desc)
		,getdate()
		,'A')
	end

	

	
	
END
GO
/****** Object:  StoredProcedure [dbo].[pUpdateNotify_tr_event]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pUpdateNotify_tr_event] (@tr_event_id int) 
AS
BEGIN
	
	update tr_event set notify_datetime = getdate()
	where ID = @tr_event_id

END
GO
/****** Object:  Trigger [dbo].[insert_setting_event]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[insert_setting_event]
   ON  [dbo].[ct_setting]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @tr_setting_id int
    DECLARE @temp_number int

	-- last setting data
	DECLARE @temp_name nvarchar(100)
	DECLARE @tool_id int
	DECLARE @tool_name nvarchar(100)
	DECLARE @location_id int
	DECLARE @location_name nvarchar(100)
	DECLARE @foor_id int
	DECLARE @foor_name nvarchar(100)
	DECLARE @limit_hi decimal(5,2)
	DECLARE @limit_low decimal(5,2)
	DECLARE @warning_hi decimal(5,2)
	DECLARE @warning_low decimal(5,2)
	DECLARE @enable_limit_hi varchar(1)
	DECLARE @enable_limit_low varchar(1)
	DECLARE @enable_warning_hi varchar(1)
	DECLARE @enable_warning_low varchar(1)
	DECLARE @enable_line varchar(1)
	DECLARE @enable_temp varchar(1)

	-- user edit data
	DECLARE @user_temp_name nvarchar(100)
	DECLARE @user_tool_id int
	DECLARE @user_tool_name nvarchar(100)
	DECLARE @user_location_id int
	DECLARE @user_location_name nvarchar(100)
	DECLARE @user_foor_id int
	DECLARE @user_foor_name nvarchar(100)
	DECLARE @user_limit_hi decimal(5,2)
	DECLARE @user_limit_low decimal(5,2)
	DECLARE @user_warning_hi decimal(5,2)
	DECLARE @user_warning_low decimal(5,2)
	DECLARE @user_enable_limit_hi varchar(1)
	DECLARE @user_enable_limit_low varchar(1)
	DECLARE @user_enable_warning_hi varchar(1)
	DECLARE @user_enable_warning_low varchar(1)
	DECLARE @user_enable_line varchar(1)
	DECLARE @user_enable_temp varchar(1)

	
	-- Get temp_no
	select top 1 @tr_setting_id = s1.id
		, @temp_number = s1.temp_number
	from ct_setting s1
	order by s1.id desc

	--	Get last setting params by temp number on ct_setting
	select top 1 @temp_name = s1.temp_name
		, @tool_id = s1.tool_id
		, @tool_name = (select x.tool_name from ct_tool x where x.tool_id = s1.tool_id)
		, @location_id = s1.location_id
		, @location_name = (select x.location_name from ct_location x where x.location_id = s1.location_id)
		, @foor_id = s1.foor_id
		, @foor_name = (select x.foor_name from ct_foor x where x.foor_id = s1.foor_id)
	from ct_temp s1 
	where s1.temp_number = @temp_number and s1.status_flag = 'U'	
	order by id desc

	select top 1 @limit_hi  = s1.limit_hi 
		, @limit_low  = s1.limit_low 
		, @warning_hi = s1.warning_hi 
		, @warning_low = s1.warning_low
		, @enable_limit_hi = s1.enable_limit_hi
		, @enable_limit_low = s1.enable_limit_low
		, @enable_warning_hi = s1.enable_warning_hi
		, @enable_warning_low = s1.enable_warning_low
		, @enable_line= s1.line_active
		, @enable_temp = s1.temp_active
	from ct_setting s1 
	where s1.temp_number = @temp_number and s1.status_flag = 'U'
	order by id desc
	   
	--	Get user setting params by temp number on ct_setting
	select top 1 @temp_name = s1.temp_name
		, @user_tool_id = s1.tool_id
		, @user_tool_name = (select x.tool_name from ct_tool x where x.tool_id = s1.tool_id)
		, @user_location_id = s1.location_id
		, @user_location_name = (select x.location_name from ct_location x where x.location_id = s1.location_id)
		, @user_foor_id = s1.foor_id
		, @user_foor_name = (select x.foor_name from ct_foor x where x.foor_id = s1.foor_id)
	from ct_temp s1 
	where s1.temp_number = @temp_number and s1.status_flag = 'A'	
	order by id desc

	select top 1 @user_limit_hi  = s1.limit_hi 
		, @user_limit_low  = s1.limit_low 
		, @user_warning_hi = s1.warning_hi 
		, @user_warning_low = s1.warning_low
		, @user_enable_limit_hi = s1.enable_limit_hi
		, @user_enable_limit_low = s1.enable_limit_low
		, @user_enable_warning_hi = s1.enable_warning_hi
		, @user_enable_warning_low = s1.enable_warning_low
		, @user_enable_line= s1.line_active
		, @user_enable_temp = s1.temp_active
	from ct_setting s1 
	where s1.temp_number = @temp_number and s1.status_flag = 'A'
	order by id desc


	--- ST = Setting
	---- Check temp name
	if (@temp_name != @user_temp_name)
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, CONCAT('Change temp name from "',@temp_name,'" to "',@user_temp_name, '"'))
		end
	
	---- Check limit_hi
	if (@limit_hi != @user_limit_hi)
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, CONCAT('Change limit hi from "',@limit_hi,'" to "',@user_limit_hi, '"'))
		end

	---- Check limit_low
	if (@limit_low != @user_limit_low)
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, CONCAT('Change limit low from "',@limit_low,'" to "',@user_limit_low, '"'))
		end

	---- Check warning_hi
	if (@warning_hi != @user_warning_hi)
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, CONCAT('Change warning hi from "',@warning_hi,'" to "',@user_warning_hi, '"'))
		end

	---- Check warning_low
	if (@warning_low != @user_warning_low)
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, CONCAT('Change warning low from "',@warning_low,'" to "',@user_warning_low, '"'))
		end

	---- Check enable_limit_hi to 'N'
	if (@enable_limit_hi != @user_enable_limit_hi and @user_enable_limit_hi = 'N')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Disable Limit hi')
		end

	---- Check enable_limit_hi to 'Y'
	if (@enable_limit_hi != @user_enable_limit_hi and @user_enable_limit_hi = 'Y')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Enable Limit hi')
		end

	---- Check enable_limit_low to 'N'
	if (@enable_limit_low != @user_enable_limit_low and @user_enable_limit_low = 'N')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Disable Limit low')
		end

	---- Check enable_limit_low to 'Y'
	if (@enable_limit_low != @user_enable_limit_low and @user_enable_limit_low = 'Y')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Enable Limit low')
		end

	---- Check enable_warning_hi to 'N'
	if (@enable_warning_hi != @user_enable_warning_hi and @user_enable_warning_hi = 'N')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Disable Warning hi')
		end

	---- Check enable_warning_hi to 'Y'
	if (@enable_warning_hi != @user_enable_warning_hi and @user_enable_warning_hi = 'Y')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Enable Warning hi')
		end

	---- Check enable_warning_low to 'N'
	if (@enable_warning_low != @user_enable_warning_low and @user_enable_warning_low = 'N')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Disable Warning low')
		end
	---- Check enable_warning_low to 'Y'
	if (@enable_warning_low != @user_enable_warning_low and @user_enable_warning_low = 'Y')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Enable Warning low')
		end

	---- Check enable_line to 'N'
	if (@enable_line != @user_enable_line and @user_enable_line = 'N')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Disable Line notify')
		end

	---- Check enable_line to 'Y'
	if (@enable_line != @user_enable_line and @user_enable_line = 'Y')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Enable Line notify')
		end

	---- Check enable_temp to 'N'
	if (@enable_temp != @user_enable_temp and @user_enable_temp = 'N')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Diable Temp')
		end

	---- Check enable_temp to 'Y'
	if (@enable_temp != @user_enable_temp and @user_enable_temp = 'Y')
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @tr_setting_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, 'Enable Temp')
		end
END
GO
ALTER TABLE [dbo].[ct_setting] ENABLE TRIGGER [insert_setting_event]
GO
/****** Object:  Trigger [dbo].[insert_name_event]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[insert_name_event]
   ON  [dbo].[ct_temp]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @ct_temp_id int
    DECLARE @temp_number int

	-- last setting data
	DECLARE @temp_name nvarchar(100)
	DECLARE @tool_id int
	DECLARE @tool_name nvarchar(100)
	DECLARE @location_id int
	DECLARE @location_name nvarchar(100)
	DECLARE @foor_id int
	DECLARE @foor_name nvarchar(100)


	-- user edit data
	DECLARE @user_temp_name nvarchar(100)
	DECLARE @user_tool_id int
	DECLARE @user_tool_name nvarchar(100)
	DECLARE @user_location_id int
	DECLARE @user_location_name nvarchar(100)
	DECLARE @user_foor_id int
	DECLARE @user_foor_name nvarchar(100)


	
	-- Get temp_no
	select top 1 @ct_temp_id = s1.id
		, @temp_number = s1.temp_number
	from ct_temp s1
	order by s1.id desc

	--	Get last setting params by temp number on ct_setting
	select top 1 @temp_name = s1.temp_name
		, @tool_id = s1.tool_id
		, @tool_name = (select x.tool_name from ct_tool x where x.tool_id = s1.tool_id)
		, @location_id = s1.location_id
		, @location_name = (select x.location_name from ct_location x where x.location_id = s1.location_id)
		, @foor_id = s1.foor_id
		, @foor_name = (select x.foor_name from ct_foor x where x.foor_id = s1.foor_id)
	from ct_temp s1 
	where s1.temp_number = @temp_number and s1.status_flag = 'U'	
	order by id desc
	   
	--	Get user setting params by temp number on ct_setting
	select top 1 @temp_name = s1.temp_name
		, @user_tool_id = s1.tool_id
		, @user_tool_name = (select x.tool_name from ct_tool x where x.tool_id = s1.tool_id)
		, @user_location_id = s1.location_id
		, @user_location_name = (select x.location_name from ct_location x where x.location_id = s1.location_id)
		, @user_foor_id = s1.foor_id
		, @user_foor_name = (select x.foor_name from ct_foor x where x.foor_id = s1.foor_id)
	from ct_temp s1 
	where s1.temp_number = @temp_number and s1.status_flag = 'A'	
	order by id desc



	--- ST = Setting
	---- Check temp name
	--if (@temp_name != @user_temp_name)
		begin
			insert into tr_event (create_datetime, tr_temp_id, temp_number, temp_name, tool_id, tool_name, location_name, foor_name, event_type, event_detail)
			values(GETDATE(), @ct_temp_id, @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, 'ST'
				, CONCAT('Change temp name from "',@temp_name,'" to "',@user_temp_name, '"'))
		end
	
	
END
GO
ALTER TABLE [dbo].[ct_temp] ENABLE TRIGGER [insert_name_event]
GO
/****** Object:  Trigger [dbo].[auto_insert_setting]    Script Date: 3/10/2022 2:55:23 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[auto_insert_setting]
   ON  [dbo].[tr_temp]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.d
	SET NOCOUNT ON;
	
	----------------------------------------------------------------------------------------------------------------------
    -- Update ct_setting for tr_temp table
	----------------------------------------------------------------------------------------------------------------------
	--update dbo.tr_temp
	--	set ct_setting_t1 = (select top 1 ct_setting_t1 from tr_temp where ID = (select top 1 ID from tr_temp order by ID desc)-1)
	--		,ct_setting_t2 = (select top 1 ct_setting_t2 from tr_temp where ID = (select top 1 ID from tr_temp order by ID desc)-1)
	--		,ct_setting_t3 = (select top 1 ct_setting_t3 from tr_temp where ID = (select top 1 ID from tr_temp order by ID desc)-1)
	--		,create_datetime = getdate()
	--	where ID = (select top 1 ID from tr_temp order by ID desc)

	DECLARE @temp_actual decimal(5,2)
	DECLARE @sid int = null
	select top 1 @sid = tr.ID , @temp_actual = tr.temp_actual from tr_temp tr order by tr.ID desc
	if (ISNULL(@sid,0) = 0) begin return; end

	DECLARE @tr_temp_id int	
	DECLARE @temp_number int	
	DECLARE @ct_temp_id int
	DECLARE @ct_setting_id int
	DECLARE @temp_name nvarchar(100)
	DECLARE @tool_id int
	DECLARE @tool_name nvarchar(100)
	DECLARE @location_name nvarchar(100)
	DECLARE @foor_name nvarchar(100)
	DECLARE @alarm_hi decimal(5,2), @alarm_lo decimal(5,2)
	DECLARE @warning_hi decimal(5,2), @warning_lo decimal(5,2)
	DECLARE @ena_ahi varchar(1), @ena_alo varchar(1)
	DECLARE @ena_whi varchar(1), @ena_wlo varchar(1)
	DECLARE @ena_line varchar(1)
	DECLARE @ena_temp varchar(1)

	--	Get temp number on tr_temp table
	select top 1  @tr_temp_id = s0.ID
			, @temp_number = s0.temp_number
		from tr_temp s0 order by id desc

	-- Get ct_temp_id by temp number on ct_temp
	select top 1  @ct_temp_id = s2.ID 
			,@temp_name = s2.temp_name
			,@location_name = (select top 1 location_name from ct_location st where st.location_id = s2.location_id)
			,@foor_name = (select top 1 foor_name from ct_foor st where st.foor_id = s2.foor_id)
			,@tool_id = s2.tool_id
			,@tool_name = (select top 1 tool_name from ct_tool st where st.tool_id = s2.tool_id)
		from ct_temp s2 where s2.temp_number = @temp_number and s2.status_flag = 'A'
	
	--	Get last setting params by temp number on ct_setting
	select top 1  @ct_setting_id = s1.ID 
			, @alarm_hi = s1.limit_hi 
			, @alarm_lo = s1.limit_low 
			, @warning_hi = s1.warning_hi 
			, @warning_lo = s1.warning_low
			, @ena_ahi = s1.enable_limit_hi
			, @ena_alo = s1.enable_limit_low
			, @ena_whi = s1.enable_warning_hi
			, @ena_wlo = s1.enable_warning_low
			, @ena_line = s1.line_active
			, @ena_temp = s1.temp_active
		from ct_setting s1 where s1.temp_number = @temp_number and s1.status_flag = 'A'

	


	--	Update tr_temp setting
	update dbo.tr_temp
		set ct_temp_id = @ct_temp_id
			,ct_setting_id = @ct_setting_id
			,plc_datetime = getdate()
			,create_datetime = getdate()
		where id = @sid


	--return;
	----------------------------------------------------------------------------------------------------------------------
	-- Insert event when low/high alarm
	----------------------------------------------------------------------------------------------------------------------

	-- check condition for insert to tr_event	
	declare @last_status varchar(2)
	set @last_status = (select top 1 x.event_type from tr_event x where x.temp_number = @temp_number order by x.ID desc)

	if (@temp_actual > @alarm_hi and @ena_temp = 'Y' and @ena_ahi = 'Y') begin		--	Temp alarm high --> HH
		if(@last_status <> 'HH' or @last_status is null) begin  
			insert into tr_event (create_datetime, temp_number, temp_name, tool_id, tool_name, location_name, foor_name,event_detail, tr_temp_id, event_type)
			values(GETDATE(), @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, CONCAT('actual temp: ',@temp_actual,' C more than ',@alarm_hi, ' C'),@sid,'HH')
		end
	end
	else if (@temp_actual <= @alarm_hi) and (@temp_actual > @warning_hi) and (@ena_temp = 'Y' and @ena_whi = 'Y') begin		--	Temp warning high --> H
		if(@last_status <> 'H' or @last_status is null) begin  
			insert into tr_event (create_datetime, temp_number, temp_name, tool_id, tool_name, location_name, foor_name,event_detail, tr_temp_id, event_type)
			values(GETDATE(), @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, CONCAT('actual temp: ',@temp_actual,' C more than ',@warning_hi, ' C'),@sid,'H')
		end
	end
	else if (@temp_actual >= @alarm_lo) and (@temp_actual < @warning_lo) and (@ena_temp = 'Y' and @ena_wlo = 'Y') begin		--	Temp warning low --> L
		if(@last_status <> 'L' or @last_status is null) begin  
			insert into tr_event (create_datetime, temp_number, temp_name, tool_id, tool_name, location_name, foor_name,event_detail, tr_temp_id, event_type)
			values(GETDATE(), @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, CONCAT('actual temp: ',@temp_actual,' C less than ',@warning_lo, ' C'),@sid,'L')
		end
	end	
	else if (@temp_actual < @warning_lo) and (@ena_temp = 'Y' and @ena_alo = 'Y') begin		--	Temp alarm low --> LL
		if(@last_status <> 'LL' or @last_status is null) begin  
			insert into tr_event (create_datetime, temp_number, temp_name, tool_id, tool_name, location_name, foor_name,event_detail, tr_temp_id, event_type)
			values(GETDATE(), @temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, CONCAT('actual temp: ',@temp_actual,' C less than ',@alarm_lo, ' C'),@sid,'LL')
		end
	end	
	else if ( @temp_actual >= @warning_lo and @temp_actual <= @warning_hi ) begin	--	Temp in range
		if(@last_status <> 'N') begin
			insert into tr_event (create_datetime, temp_number, temp_name, tool_id, tool_name, location_name, foor_name,event_detail, tr_temp_id, event_type)
			values(GETDATE(),@temp_number, @temp_name, @tool_id, @tool_name, @location_name, @foor_name, CONCAT('actual temp: ',@temp_actual,' back in range ',@warning_lo , ' C - ',@warning_hi,' C'),@sid,'N')
		end
	end	
	
END
GO
ALTER TABLE [dbo].[tr_temp] ENABLE TRIGGER [auto_insert_setting]
GO
USE [master]
GO
ALTER DATABASE [AJI_NK_TEMP_QC] SET  READ_WRITE 
GO
